<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_updates = "db465107191.db.1and1.com";
$database_updates = "db465107191";
$username_updates = "dbo465107191";
$password_updates = "GreenClean1";
$updates = mysql_pconnect($hostname_updates, $username_updates, $password_updates) or trigger_error(mysql_error(),E_USER_ERROR); 
?>